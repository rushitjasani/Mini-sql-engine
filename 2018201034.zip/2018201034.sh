#!/bin/bash
python 2018201034.py "$1"
